import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    title: 'Alat Musik',
    home: Alatmusik()

    ,
  ));
}

class Alatmusik extends StatelessWidget {
  const Alatmusik({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alat Musik'),
      ),
      body: Center(
        child: ElevatedButton(
          child: const Text('Drum'),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Drum()),
            );
          },
        ),


      ),
    );
  }
}

class Drum extends StatelessWidget {
  const Drum({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Drum"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'https://s3.bukalapak.com/img/3040149807/large/Drum_DW_Collectors_SA7___TG7.jpg',
                  fit:BoxFit.fill,
                ),

                new Text(
                  "Drum\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Drum adalah kelompok alat musik perkusi yang terdiri dari kulit yang direntangkan dan dipukul dengan tangan atau sebuah batang. Selain kulit, drum juga digunakan dari bahan lain, misalnya plastik. Drum terdapat di seluruh dunia dan memiliki banyak jenis, misalnya kendang, timpani, Bodhrán, Ashiko, snare drum, bass drum, tom-tom, beduk, dan lain-lain.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Drum",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Bass Drum \nSnare Drum \nTom \nCymbal",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Gitar Electric'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>  const GitarElectric()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class GitarElectric extends StatelessWidget {
  const GitarElectric({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Gitar Electric"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'https://images.tokopedia.net/img/cache/500-square/product-1/2019/11/13/24083600/24083600_2b9aaa83-d4ee-4b2f-be3a-45f9b5981336_2048_2048',
                  fit:BoxFit.fill,
                ),

                new Text(
                  "GITAR ELECTRIC\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Gitar elektrik adalah jenis gitar yang menggunakan beberapa pickup untuk mengubah bunyi atau getaran dari string gitar menjadi arus elektrik yang akan dikuatkan kembali dengan menggunakan seperangkat amplifier dan pengeras suara. Suara gitar elektrik dihasilkan dari getaran senar gitar yang mengenai kumparan yang ada di badan gitar yang biasa disebut pickup. Terkadang sinyal yang keluar dari pickup diubah secara elektronik melalui guitar effect dengan tambahan reverb ataupun distorsi.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Gitar ",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Tuning Page \nHead Stock \nNut \nFrets \nNeck \nBody \nPickups \nBridge \nPickup Switch \nVolume and Tone Control \nTremolo.\n ",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Piano'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Piano ()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class Piano extends StatelessWidget {
  const Piano({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Piano"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/Steinway_%26_Sons_concert_grand_piano%2C_model_D-274%2C_manufactured_at_Steinway%27s_factory_in_Hamburg%2C_Germany.png/1200px-Steinway_%26_Sons_concert_grand_piano%2C_model_D-274%2C_manufactured_at_Steinway%27s_factory_in_Hamburg%2C_Germany.png',
                  fit:BoxFit.fill,
                ),

                new Text(
                  "Piano\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Piano (yang juga disebut pianoforte) adalah alat musik tuts yang diklasifikasikan sebagai instrumen dawai dan perkusi yang dimainkan dengan menekan tuts-tuts pada papan piano. Setiap tuts tersambung ke palu yang ada di dalam piano dan menekan senar di dalamnya, sehingga menghasilkan bunyi. Setiap senar memiliki panjang yang berbeda dan menghasilkan bunyi yang berbeda pula.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Piano",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Tuts \nPedal \nDawai \nMartil \nBody.\n  ",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Bass'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Bass()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class Bass extends StatelessWidget {
  const Bass({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bass"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'https://images.tokopedia.net/img/cache/700/product-1/2020/2/4/224043/224043_903c8300-1d10-4463-96dd-72bba749f768_551_551.jpg',
                  fit:BoxFit.fill,
                ),

                new Text(
                  "Bass\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Bass adalah jenis suara terendah penyanyi pria, biasanya mempunyai jangkauan dari nada E2 sampai E4.[1] Walaupun demikian, beberapa penyanyi yang nada rendahnya bisa sangat ekstrem, bisa mencapai nada C2.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Bass",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Tuning Keys \nHeadstock \nNut \nNeck \nFingerboard \nFrets \nStrap Pin \nBody.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Gitar Akustik'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Gitarakustik()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class Gitarakustik extends StatelessWidget {
  const Gitarakustik({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Gitar Akustik"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'http://3.bp.blogspot.com/-xtI25zyz5LA/VrGMwjEF1iI/AAAAAAAAAN0/XDKwP7PTFsQ/s1600/10019571.jpg',
                  fit:BoxFit.fill,
                ),

                new Text(
                  "Gitar Akustik\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Gitar akustik adalah jenis gitar di mana suara yang dihasilkan berasal dari getaran senar gitar yang dialirkan melalui sadel dan jembatan tempat pengikat senar ke dalam ruang suara. Suara di dalam ruang suara ini akan beresonansi terhadap kayu badan gitar. Jenis dan kualitas kayu serta jenis senar yang digunakan akan memengaruhi suara yang dihasilkan oleh gitar akustik.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Gitar Akustik",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Headstock \nTuner \nNut \nFret \nNeck \nFinger Board \nBody \nSound Hole \nStrings \nSaddle \nBridge \nSound Board \nPick Guard\n",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Violin'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Violin()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class Violin extends StatelessWidget {
  const Violin({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Violin"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFRUYGBgWGh8YGBocGBgYGBgaGB4dGhwYHBkcIS4lHB4rIRkYJjgnLC8xNTY1GiQ7QDszPy40NTEBDAwMEA8QHxISHzQkJCs3NDUxNDQ0NDQ0NDQ0MTQ0NDQ0MTQ0NDQ0NDQ0PTQ0NDQ0NDQ0NDQxNDQ0NDQ0NDQ0NP/AABEIAVwAkQMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABgcDBAUBAgj/xABPEAACAQICBAkHBwoEAwkAAAABAgADEQQhBRIxQQYHIjJRYXFysROBgpGhssEUIzRCUpKzJDNic6LC0dLh8FN0k7QlQ6MWNURjZIOkw9P/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIDBAX/xAAkEQACAgIBBAMBAQEAAAAAAAAAAQIRAzEhBBIiMkFRcWGBE//aAAwDAQACEQMRAD8AuaIiACIiACIiACIiACIiACIiACIiACIiAEU4wtJth8GaqEhlq0TkSL6tRWKmxBKnVsRvBM4+hONHD16lOk9J0eo6opBV0DMQq3ORAJIGw7ZKOEug6eNQUKrMEJ1zqEAnVIsLkGwufZK14ScD6GBxej2oM+q+Jphgza1itSnmDbfrbOqS7s1j2tU9lyRPIlGR9REQAREQAREQAREQAREQAREQAREQAREQAxHnjut4rIVxiJepgD9nE0z661AfGTU88d1vFZD+MDnYTqr0/wDcYeJjWyaREQA9iIjEIiIAIiIAIiIAIiIAIiIAIiIAIiIAYjzx3W8VkO4wedhP19P/AHGGkxPPHdbxWQ7jD24X9dT/ANxhohrZNYiIAexERiEREAPIiaekcelBQzkgEhRYXJJ2D2GDdDSvhG5EpXQXCpVrUqj1G1de7ZscmLKctlgHlxYTErURKiG6uoZTsuCLiTGSZeTG4VZsxESjMREQAREQAREQAxNz17reKyGcZBsMMeiqn+4w8mZ547reKyFcZnMo/rE/Hw8Q1snMREAPYiIxCIiAHkpbhTSxlDEYh6tOpUorUapTcmo1Jb3dNW5spW5U7rawAAtLpkV4y6aHRuJ1yQFQMLGx1gw1fNrWkyVqi8cu12ij6ePcIqWQKcO1EmwzDuHJ717G/VLC4rMJjlr/ADy16dBKJstQVFTWZl1VVWyNgG2bPOJUtKkzKXtdUIUi2bAtbIkW32v1iX3hOMHRyU1ValVgqhVJo1bsFFgSSouTaKK+zTJO1wTiJWtXjILuTQVDSyALqwcm1zezWGeQykt4LaeXGUmqBdRkc02W97MArZGwuCrKfWN0qzGjuxERiEREAEREAMLc8d1vFZC+NA2pUj0On4+Hk0bnjut4rIRxqm1BO8v41CJjjsnkREYHsREBCQLjH07Ww7UKdMsqVVdmdbhiU1bKGGa5Mzdduo3ns1MZgqdZdSqiOtw1mUMAw2ML7CNx2wApnQ3C3G0nJpLVxJZRdGFeuAAw5YCklTmVv177To8IOEuMxeHfD18E9BKtgajUq6AFTrjN1Cm5UZX6ZZejNB4fDsz0aQRnsHIJJIW9hdibAXOQnB4y2YYanqm16w9QSofhJk6TZpjVzS/pROi8OjEpcksVJ5wtY3vcX6xL+0RwT0c9Ck/yLDnXpq1zSQk6yg32dcpPQl/nFpg3anTZjq3AOqj3DXyuekb7Se6J0tpsUaa0sKrU1UCkwWmdamBZGJasMyLbhFF8tFTj4pkixvFxgnq66NUoAgA06Jpoh1frWKEgnK5BGySXQuh6OEpCjRUqoJY3JZmJ2szHMk/ADYJR2nNJ4jy+tjl1a2qpIZUWyfVICkgDI+e8svisxtSrhnZizUxUK0WN81CjWCk7UDXA69YbrCjJk5iIjEIiIAIiIAYjz17reKyC8bRthk7y/i0ZOW5w7reKyCcbx/Jl7w/EpSXoqG0T+IiMR9RERiErvjMTFF6Xk1rvQ1W1vIGrrLUvkXWmblSuwnIWPTLEiAFF8G6Wky9T5ElRbanli5RS55RUXro17cq9vtDqt2dIppML/wAQa9J+RTAagbVnBVDyEVrWLDM2z7JbUjvDNAaKXANqqHMA22gnPqJktWqKjKmmUvoKsyObDVR0ohgxFtXVUapvnkVWXjwRN8Fhj00U90SnNJ0FLjkjNqIIAsLE3IsJbnAQ30dg/wDL0x6lAiUVdjlJ1R0sXonD1WD1aFJ3UWDPTRmUXvYMRcC+c20QAAAAAZADIAdAEyRLIEREAEREAEREAMTc4d1vFZAuOH6KveHv05PW5w7reKyB8cH0Ve39+nJemVDaJ/ERGI+oiIxCIiAHkj/DJrUV75P3adRv3ZIZHOGZ+aUdLP8Ag1B8YmBVukBZx36B/ZB/jLP4u/8Au3C33UgPUSPhKz00NUE7w9LPsQyyuLhr6Oofomon3KtRPhEhslEREoQiIgAiIgAiIgBhbnDut4rIHxwfRR2n36cnjc8d0+KyB8cP0Ve0+8kl6ZUNon94nkQAyRESiRERADyRzhgeQg63P7BH70kci/DNrCn2Mf2qa/vRPQ0Vpwgbkv3qftRpZfFyfyFB0VcQP/kVT8ZWWn+Y/epfhv8Awlk8Wr3wXZXxH4zn4xIbJbERKJEREAEREAEREAMTc8d0+IkA44j+Sr2n3kk+bnjunxWQDjk+jL2n3kkvTLhtE+iIiAzxESyBERADyRLhsc06kc/9XD/1ktkN4bNygOin41af8piehrZXfCHm1O+g9SPLF4rz+RuOjE1x/wBQn4yuOEZyqjoqKPUtUfCWFxVvfDVurFVR69U/GJAybxEShCIiACIiACIiAGFueO6fFZX3HL9GTtPvU5YJ547p8RK+45D+Tp6XvU5L0y4bRP4iIhmxERLMzyInC0xwow+HvrPcjIqtjY9BYkKG6ib9UTaWxqLk6R3ZCeGj/O2/8tPa7n9yc3F8ZRN/I0L22MxJHq5PsvOTW01UxOtVqgBrolgLAACuw3np6ZH/AEi3SNXhnFd0lwcXhGcq367/APeTrija+HxXVjKnm+bpf1kB4SNlX/zB8a8+ODnC+vgnq0qSoy1Kr1GDKSb3C3BDDcoylXStkKLk6Rf8StsBxni4FeiV/SU2/ZbL9qTbRGnKGJXWo1A1tq7GXvKcx4QUovTHLFOO0dSIiUZiIiACIiAGI88dh8RK745j+Tp6Xv0pYZ547p8RK745/o9P0vepyXpl4/ZFhXifMRDNmIkT4f6e+S4c6v5yryEHSTl8erINY3EpulZEYuTpHE4acMW1jh8MbkDlsNwPWMwOgCxbbcLbXhWF0c9Q6zkm2QJ6OhRsUdQna0No4JTJY6zvy3Y5kscybzdwtETjlKUn/D1scI4o0tmLBaLUDZNbGUwpcD7VP3MQfjO+tgJwdIvdm66ij7tNv55WONSMc8nKPJwuEOyt/mD415Hg1sST+k/iZ3tOnKr/AJg+OIkfqZV/SM3mvFnLhdZF+naFQHaJ7QqtSYPRZkZTcWJBB6ujs2HeDNIvafPlcpxrg9l01yXJwI4YDFjyVWy11F+gVFG1gNzDePOMrhZjafm/B4p6dRatNtV0YOh3AjcRvBuQRvBI3z9A6F0iuJoU665Cooa29TsZT1g3HmnZjl3Lk8fqMPZLjTOjERNDnEREAMJ547p8RK546T+T0/S96nLFPP8AR+Ilc8dX0en6XvU5L0y8fsiwdaJ8xEUbsp3jBxhq6RSjfk0Vv1XIyJ6wS488uIykNPn/AIniCd1rdms39JOV+Jp0quZ3cObKBM1C15z0q5T7SvOZNHfKLN2vWtOBinu4/WN7EofzGdDEvOUpu6/rH93DCa43cjnzqoL9OVpluTU/X/CvI9iGtVv0nxAnb0o11frqjwrzhYtuWp2X1faimbS9WcmN+aNtjnPL5T0iehZxnsntM7ZbnFHii2HqUj/y31l6lqAEj76ufPKkUZyzuJ3ZiOj5secNV/iJrhfkcvWLwLNiInUeWIiIAYfr+j8ZW/HZ9Hp+n71OWR9f0fjK247PzFL0/GnJemXj9kWBEREUb0pbh5Q8lpMsdlZAw81viHl0ytuODA/N0MSozpPqtberZ59Qsw9OGRXErp5dsyMpXM+1rb5zEr3AmVKs4aPY2ddKgO2c8H5xB0u59bU1/cM+6TzXoNetT7T+O4+E2wrlnF1fov05OkWujfrF92tOFjzylPc9xZ2MYfmz+sT3a04ukNq+h7gnRLRw4/ZG6hmZRlMK7BPQ2U42j2kzOr7ZbPFBhSuEeqf+bVOr3UAX3teU+7WBP97yfCforg1o75PhaFHeiKG63Iux87Fj55vhjzZx9bPxUTrREToPNEREAMP1/R+MrXjt/M0vT8aUsr6/o/EytOO381R9P3qUl6ZeP2RYUT6tERRuSE8a2MRMC9NjyqpVVG/ksrE9mxfSk2nG09wcw2N1PlCF/JklbMyc61wSpBIyHqlNWqIjJKSbKKwz8gdg8JsB5MeGfACnQotiMHrKKY1npFmdSg2spYkggZ5k5DqsYRT5QDDeJyyh27PVw5VNcHQoPee4HOpT/v8A8TVmHDnZMuDdUq0lY2JCWv0vVdwP25WHbMus9UcXEn5v0092rOTpPaOyn+Gs6eIqqaZswPLTf+hVnMx2fqT3Fmz0cMPZG3RFxefVp84Y8kTNQoM7JTTn1HVF7XIUe0icx6yfFmJ2FiL9I9YI+M/RnB7Sq4rD0665B1uR9lgSrL5mDDzTn6E4F4TD0wnkadRrWZ3RWZjvPKvYdQyncwmFp0kCU0VFW9lUBVFyWNlGQuST550Qi4nm58yyaRsxETQ5xERADCOee6PEys+O0/N0Oyp71GWYOee6PEyseO7mYfsqe9RkvReP2RZVon1aIDNieT2JRmYMVRDoyHYylT2MCD4z876NHIF9xI9s/RjmwvPzpo9uRfpJMxzfB2dJtmzTm7VphqtK/wBXyJH3UaR5ca7B6iZKl9Xk6xYrmSR9m3R27rHv4eqWak1rayU27PmkMxcXHk7O6M7X8I++BXUI3a1P2JWmticEA3oJ7iTo1X5J7ye7VmhpGsVGsBckKOn6qjZ5ok5PgbjCNuj2ithad3gUgbSOFB2a5PnVSw9oEjS1mVgGNw2w2AIPQbZSQ8Dq+rj8Kx2eUC/f5A9rSkqkiJSThKvo/Q8TyezrPJEREAEREAMQ5x7o8TKu47zycN2VfeoS0Bzz3R4tKs48D9F7tX3qEmWi8fsi04iIAZonw7AC5yAzvumGhi6boHR0ZCLhlZShHSGBtaUQaPCfGihha9Qm2qhC9bMNVR52IEoaoNXDMdh1GP3r/wAZOuMjTwrlcLSN01rsdzG20dKAE57yQdgBMK04urh3A+yB5rgTGbuSR24IuMGzW4PZUUI6WP7RnerH53bsQ+yl/ScvgdTosqDEOUQaxJVWYsdbJRqg6t7nO27rBkyrtosu16zI/KuLVd6nW2oRzSenzzKSbf8ApusijFJr4IFV2N1PT92rMFb6vd8GYfCTQ0dD2N8WxXWW977bPqi/kgdhb1Ti8J00ctNWwuILOpA1CHIdGJuQSgAIJv1i/VF2spZotkVxTCy9R/jNzDYgoyOvOpurjtQhh7QJzcaeTcdI+M2wenfeP4TJTuUkfp/CYhaiJUU3V1DKekMLj2GZ5U3Fzw3SlTGFxLaqplTqHmqu3Vc7lG5tgGRtlewK3CXBqL/KKbDbyGFQgb2IS5CjaScgMzOlSTVnnTg4yo7UREogREQAwjnnujxaVVx5H6L3K3vYeWqOee6PFpVHHntw3cq+9Rky0aY/ZFq3ieXiAzT4SUqj4WutIKztTZVVr2a4sVy3kXA6yJQ1DTTvy/I0S52vqajFullQqjHp5Il4cMdKfJ8JUcGzEaid98gR2C7ejKJwVIZ23m/mkZGbdNC7Z7V0gKba9Qksx2gZ2G4AbFF/bvJn3wgxA+Tmxvr6ur1gkN4AxpDRi1gBcKy5qTcrntVrZ2OWYzFp8YnBmoV8oVCJayKSQTbpIFlyt026L3GfHDN2pcxS/Bo8atJFP2QT6Wfxm5VQGrTbc4QdoIWm/tDiYKrZzG+KAannmmRzH22f960m+bNnFKNM0Hw3IbvIfUHH70169DJe78T/AEm/5QAOOz2NMVUi3q8B8bxNsSjFnNxFPkn1+rOZqdTWVekqo84ABPrBMyOtxNZE1T1Xv1yk7VEyi4y7l9UbZplTYmxGYI6Jsvi66qUR9UPyTq2TWB3OyWLDtJmnVrFzc7hYDqnzUclezw2RJ8jauPOz9QaPw5p0qdNnLlEVCx5zFVALHrNrzZnE4I6ZGLwlKv8AWZbOOh15LjsuCR1ETtzrR5TVM9iIgIwrzj3V8WkA40NDJiDTLMy6i6o1bZ+Vq0kN7jdaT9ee3dXxaRTh0Ob2J+PTkvQ4unwSDyx6ImvrT2KyiveN7SRarRwynJV127WNvWFUj/3JD6QsJt8NMT5TSeJa9wjBB1aqKrD1qZoq+UxyO2eh08Uooylp8XmO8F5mdKPirtnFeoTr61zqsy5ELs5t+SRuP9idZzOXjqdnv0kHqzFjnvN7+uaY6umcvU2oppnziqpDVBszJG7a9xu6J8LXI6TuzvuAH8ZqPTAGRPJyF9995zy7M9sz0UAay3sMs8ic73I3TWaVHJinLvXJu62V5iaZ8phcTmPT2j51rQpnxPpTKJLK4m9L6laphGPJqDyid9QAwHWU1f8ATMuKfmjgxjTRxuGqg21aqA91m8m/7DtP0uJ0Qdo83PHtkexESzEwrz27q+LSH8Oq6qQpZQdVDYsAbfKKedie31GTBee3dXxaUvx5D8opn/0//wBjRPQ0Wb5dftL94fxiQm46oioCCaUa+Nxl9vymr77TxWm1w2wpw+ksSpFhUcVlO4ioNYkekWHmM5TV+jOYTXJ6WGXjZtF5japNF3O9x2DPwy9sxMf7MSjL6KeaK+To6018et0Db0PsOR+B801S7LnmJnSsHUjpBHrygri7FJxnBpOzSqWJHr+MyYZL5nfn65rs3JB/RP8AD4zcw3Nms3wcnTxTlZlOUxPMrGY2Exo7bMZE8tMgMFYBYpX1ltt1hbtuLe20/VAn5u4I6PNfG4ana4NRWbfyaZ8owPaqEekJ+kpvjXBxdS/Kj2IiaHMafyhBV1C6hmVSFLAMQC1yF2nf6pT/AB5Um+UUW1eS1BlU9LK92FuoOv3p3OGHCJMHpei9RSU8hTZmXNlF8WmS/WzqA7dimwN5AuG2nBjcTVq0y3k7KtMMTkFWxIW9luQTbrF88hLdDirdFpf9nqn+GfWP4xJzPZQFQ8eGGQHDVdVtc66FrcgotmCltzAsSB0F+iVW2Ivt9W7++ufpvhHoOljcO9CqMmzVhzkcc116wfWCRsM/NvCTQNfBVmo11sRmjDmOu51PR1bRsMVfI+51RritPoVppKZ9XgBuirMbOFYNuvY+ffMCmfT0yVPZE4pjjJxdo+FPIHY3sM6VO1hOZScai+kD57zZoV+SNnrkZDfA+Wbtr7PVPlhCOG6p9kTE60Yws8c2mUuAM5NOBHAV8Wy18QpXDizKpuGrdAG9U6Tv3bbhxTbpCnKMI2zv8UPB5kRsbUGdRSlEH7F7s/pEKB1JfY0tCY6aBQAAAALAAWAAyAA3CZJ0pUqPNlJyds9iIjJKS42MMaulKVMMqlsOihmNlHLrtnbssBvJA3yBvSKM6EglH1CVN1JUsLg7xLb4wuAWKx+KFei9AKKS0yKjupurOxyVGBFnG/plf6d4J18A1Ja7Uia7ck02dgNQqG1tZVt+cW1r79kllR2fo2IiMR7ORwg0Dh8ZSNLEJrrtUjJkP2kYZg+w7DcZTrxGIoHhFxU4ugS2Gtiae0AWWqo6ChNm3Zqbn7IkJrYV0bUqIyP9l1ZG+6wBn6zmDFYOnUXVqIjr9l1Vh6iIDs/LWGRb5keudVBh15zjsGZl5YngDo19uDpDuXp+4RNE8V+i/wDAf/Xr/wA8QWUtXxeBVSEwgdzsZ3dEHXqK2fZlOC46FA6s7e2fodeLHRf+A3+vX/nm9Q4C6Np7MHSPfBqe+TCgs/PGhsFWrtq0Kb1HG1VBbI7z9nzm0nOjuLbH1ba6pQXfrMGa3UqXv2EiXXhcMlNdWmioo2KqhR6hNiJwTNFnlFUiD8HuLfCYch6l8RUGYLgBFPStPZ97WMnETyNJIiUnJ2z2exEZIiIgB5Kw44fJK2BeqzKq1GBI3KzUi7WsSbKpNhLPnD4R8GqGN8l5bWtRqCooGrZiCDqsGU3U2sRBjTo7kT2ICP/Z',
                  fit:BoxFit.fill,
                ),

                new Text(
                  "Violin\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Violin adalah sebuah alat musik dawai yang dimainkan dengan cara digesek. Biola memiliki empat senar (G-D-A-E) yang disetel berbeda satu sama lain dengan interval sempurna kelima. Nada yang paling rendah adalah G. Di antara keluarga biola, yaitu dengan biola alto, cello dan double bass atau kontra bass, biola memiliki nada yang tertinggi..",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Violin",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Scroll \nPegbox \nNeck \nFingerboard \nUpper Bout \nBridge \nFine Tuner \nTallpiece \nChinrest \nLower Bout \nF-Holes \nWaist.\n",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Cello'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Cello()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class Cello extends StatelessWidget {
  const Cello({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Cello"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  "https://images.tokopedia.net/img/cache/500-square/product-1/2020/1/16/20145379/20145379_79ec1f0a-8e50-4ee0-ba90-4a20f064d82d_1442_1442",
                  fit:BoxFit.fill,
                ),

                new Text(
                  "CELLO\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Cello  adalah sebuah alat musik dawai dan anggota dari keluarga biola. Orang yang memainkan selo disebut cellis. Selo adalah alat musik yang populer dalam banyak segi: sebagai instrumen tunggal, dalam musik kamar, dan juga sebagai fondasi dalam suara orkestra modern. Ukuran selo masih lebih kecil daripada kontrabas.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Cello",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Scroll \nPegs \nNut \nFingerboard \nTop \nStrings \nF Holes \nBridge \nEnd Pin \nTall Piece \nNeck.\n",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Saxophone'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Saxophone()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class Saxophone extends StatelessWidget {
  const Saxophone({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Saxophone"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBQVFBcUFRUXFxcXGhsbGxsbGxodGh0iHBweHCAaHh4bICwkGx4pHh0eJTYlKjIwMzMzICI5PjkyPSwyMzABCwsLEA4QHhISHjImJCk7PjQyOzQ+MjI1MDI7NDIyMjA7NDIyMjIyMjIyMjI7MjQyMjI0MjIyMjIyMjIyMjIyMv/AABEIAVMAlAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYBBAcDAgj/xABCEAACAQIEBAQDBAgEBAcAAAABAhEAAwQSITEFBiJBE1FhcTKBkSNCobEUM1JicsHR8CSCkrIHFUOiFiU0Y3Ph8f/EABoBAQADAQEBAAAAAAAAAAAAAAADBAUCAQb/xAAvEQACAgEEAAQEBAcAAAAAAAAAAQIRAwQSITEyQVGBEyJhcQUzocEUI0KRsdHw/9oADAMBAAIRAxEAPwC28xXeJ4cl7d3xLO8i3bzIP3hl1HqPnFQn/PrzYY3b91ritcCKi5bZ0GZmlQJgRAOldNvFgpywWgxO09pjtXKecrD3LNtjYOHul2LZNELxBC5gCxIA2Gse9Q5pJJJ+Z3CLfKNS/wAZvcPtpdtX7rrdkpaugHSYLE6mJ2iJqzcmf8Q1xTG3iBbtPHS2eFf0ysOk/M1Reaku+JaW5baLdm0nwmAQp0201k/OtLhXCkvX8hGiqWKnzkAA/wB+VMbqFt2eyTcqP0ODWaoPL2LvYVFAQvhtYA1Zdd1k6LP3atOG49YuKSjglRJU9Lj/ACtFI54PhM8ljkiVpUdgOLWrqhlMAkgTsYMaHY61IA1IpJ9M5aa7PqlKV0eClKUApSlAKUpQClKUApSlAfNaPE+HJfUI86EMCIkEdxII9PnW/SuZRUlTPU2naIBOU8KHD5XkGfjaDpEEdx6bVt4rgWGuOtx7S+IugYSrR+ySsZl9DpUoaxSMFFUkHJvlsh04KLYItOwEk5WOZddYHcD61E8Q4dac5btvw27N2P8ACw//AGrfXldtKwIYBgdwRI+hqtl0kZ8rhkkcrRSMPhMThRltv4lmSSj9ZEmTlfcHUnXSa8+X+OIl6+lwmwXcG2HEKREQeoqNddI3OtWPE8Me31WTI7o2o/ynt7VDY3BW8SrKVy3F3Uj+tUpfExS55J04zRNJzBbW54N0hHmAZ6GkSIPb5/WpoGuW8Wa1ZRLZVyuRFuOoDZNYVmBbOBm0kToQPKrTybj2h8LcMva1BmZUknQncCRHoRVrT6hze2XszjJiSW5FspWKzV4rClKUApSlAKUpQClKUApSlAKUpQCsVmlAfNRnE+H54dNLiag/tfut5g1KViuJwU1TPU2naOac54KTbv2+kt0H1FyFykHQ9eXStnhiLbH6Sp67TojidMhRU27zGny8qkeaMUltDm1OdsqgSdOufl+cVDXXW0LyGAtyyv8AqBGX8ZrHTcMm30v+5eVygdKFZrwwYIRJ3yj8q962ou1ZQZmlKV6BSlKAUpSgFKUoBSlKAUpSgFKUoDFauLNyPswhMH4iRr22Braqs8ycefDuIHQFljkLakgD7w86iyzUI2zqEXJ0iGxuBuXrT3Lk+LDgZFDD4SsdQJjXsO5761GNi7a3rRus9xFChiVWNBOmUAkVYVxBbBvdUkGLjiQBqMx1U7a9qjEwSPi7AcFhcVWYE6E5T5VjRvevqy/fDvyLpwvitrEKWtNmCmDIII+tSFamDwNu0MttFUHUwN/fzrbrcjdcme6vgzSlK6PBSlKAUpSgFKUoBSlKAUpSgFKUoDyvXQqljsBPrVO5h4vbdWOR8uTKSV0BYq4P+kEzVwv/AAt7H8q5lc4bnBVUU+IttTqBGZ2Ghjp07wdzVDWTaaivMtaaCdt+RvXOY8PcS5bUkSzalDqHzEAAjyP96Vt2La2zba3YyZSMrNAc6xEbmZNVXiXD2tsQqhfjhMuZRCEnrI6iGGhOp100qS44lwvaRMQ1sBEaCxliSBM76e/eqD8SaLLgul5nUaVE8u4s3MOjMZYCD3JjY/MQalq24SUopozZKnRmlKV2eClKUApSlAKUpQClKUApSlAKUpQGtjCwRsoBMGJ0Fc7vXilvOyBwtuwSs6N1sSvfSPzro2K+BvY1Q3wguW1BaA/6Mh9Boc2/rWdrE96ot6dqnZpcULXQrPbEZSVG4GYkncCJ9u1QmCwiM9vxRcdbd11UK3UFZQCASRorN56ZPra+KgKEUNqEfY+QcyRO0gHWq3zfhZtWLNtQDcRSYMdwSd5kk7+pqljbUvuWE74R0PlZlyMqz05RqIMgEE/hVgqp8iYgva6hlZURWEZdVLiY7TvFWytbTflooZVU2ZpSlWCMUpSgFKUoBSlKAUpSgFKUoBSlKA18b+rb2NUTG4YPhQh2LWR9EQ/Orzj/ANW/8J/KqTjXZcOpVcxD2umQJ+zTuazNb4lXoW9N17kZh+HLbNu6DJuW3ZhlURAkgQBIPkZqM4wpw6WndiQqZ9CelWZABvrv+G1S5usRhgyMoFthuJuArrliY011ivi9wtLmFa3dtXQPCMXmuSoAGYRLfDIGkVSi03yWbadlg5PMXrwHwuFuLruG1n8auNcn5S4jlt4O4GAVM1u5rsMxiT3AQDX2rqqsCJGoPcVqaSS2uPoynqYtSv1PSlKVcK4pSlAKUpQClKUApSlAKUpQClKUBqcT/VP/AAmqPji/hCCPjtZZGxyJJPnIj2irrxf9Rd/gb8qpPFLJNoKHZZuWxIiRCLtPtWXrfGvsXNL17ke5dXtq7rlt2mUQsRNoGdyTq4Ef2PHBcLditvFXLgQI7PbLfZqJQW0UHRiRnJmfLtXmiMShLN1KrFhJdR4dtzGsGJ2j7oq52rFt2VXY3MqBlkjrkkFzlgNGnpr61WxKUpbUT5JKPJTuHXMO2KZBFuxh1aZ0JfLniN5AEnTXYbVdeE5rd4Cfs76yq9lZR27QwBNULmjgWbGlbEqz+FddiWyIUYoSzdpQgx+761dOMNcsBbp6haObUyCo+IKfPL2P8qsqPwpJry7IZvcl9S31mvGzcDKrLqGAI9jrXrWmnZSM0pSvQKUpQClKUApSlAKUpQClKUBHccMYe6f3D+VUPimJlXRS2dbtsEQsDMgIAzEAz31q98f/APTXf4D+VUnj2YWzlQOfEEKSAPgIJmNIrM1nj9i7pevcr/COIIzsA7QLDoMxWJ8JV0AkjVY13ketTWEwN0lLt0eBaVUEK5DJCkMxgAJmYiT2G+2kFZt3Eui4/h3CUW5mhs2WMoaFbJsD5etW7Dpee4gv3CLbTlWAudhBClkMFYk5TvHfWq0fGkifLwrJfC8FtPLqzzIysHZhoIK7w6ec9ydZ1rUx9hxmw/3HtlFX7ocSylZ2BjLFTvC0CyqiEGw7A+nlTimGZ2slROW4Cx8gATP1AHzrRyYE1a4f080UVN3yfXA0YWLYcEMF1BEEehHapGsVmrMVtSRE3bszSlK6PBSlKAUpSgFKUoBSlKAUpSgIfmXN+jXMpjpM+vSdB5ax9Ko+Pu3Qbg0YC8YkwFi0NNBrJlvwq98yH/D3PaqBxq+yrdKrmJxDLEx/0gJ2PntWVrPzPYv6XwsjsGMR4lzM+d1sZXDAkhckgg6SYaa+lxbulvIJtIhUhQ6oSoHU2bpBB2jvPcVrWMez4i49sdNxFQ6wNERTDxG666d4q7YPF4hMqDAMEGnTetQAPQx+NVubomm9vkboAJGdQrBVISZCgj4l0GpO5+XarFhySgneKqNziuIS+UTBNiLSDodcgKmTmAa4QOk9MDXT0qO45zPceAk2lA1AYFyfI5dV7QNz9K01nUIpso/ClKR0WlQvLXFPHtAkEFIUkmcxAHVt3qaqxCamrRDJOLpmaUpXZ4KUpQClKUApSlAKUpQClKUBEcx/qG9Sv51ScVg2usyq+SMTccmCZVEWVEEQSNJ7VduYz9j7sg+rCqM/FFtuxbQeJfG++YZfLtG5rJ1T/m8l7TJ7HR82MBat3MaLaKpymBlAAHhq2X2zNWlieJYy5Ztk+JZtKyKbg+NgYUkhTqJJg+1elvFpdxFzKQy3SkDXUDKrCYytOUCfX1qU5nxVz9GK+A4BZBmJSBFxTqJkz6VVUnZO1TPp+J4mxhmUlba21ITLb62CrLNqxgaNJIBMEiqlj7Au2HZL62tS7OzZM0QQrRPVoogdxUzzHfN24y5ZS3AVgxGsQwI7wxjWoe/wdiEN1AEJLpGxmI7dgf61PDJbTk7o8eOo0uGy3/8ADHGF/GUGUGQqYInSC0HYEj8K6BXNOXuNphFcC0XZyNQQuijRdj3JPzqbs88pPXZuL6gq34aVdxZ8aVXRTyY5uV0XGlRPD+YMNeMJcXN+y3S30O/yqVmrSkpdMgaa7PqlKV0eClKUApSlAKUpQClKwaAiOYT9mvq9v/etc+x9xYuglpU3igBPxZogeZOYwO+tdA5iPRb/APkT/cK57jQpN0RPTiD8/EtjT5HesjV/mmhpfCQ2IxCW7l65ZQW1JXIz5xlylSCAATusx61K8W43cv21subCPmts0O5aAQ+nTAkRv2NR/Bry5L9vfKrbycir9/1MBvcxW7d4bbVbV+2biuxXqLSdElZnQwVHp5VXlNRfJbUFJnticQrK7qGAYu3VHfM2kdpHfvNTfHNcJhBAgzr7KYE+Wv4VDWmW5YtvlhiGDn9ogfF6SDtVzTh3jYBE+8q5l9wTUuCO7cl6FfPLbtb9Sl4QjxCuUtpBOgAPaSa97XD2zlWEfOfyqkc1XL2HxAYzleNCJAYbjXTaDXpwnjnUSconqJIKnN6OpzLIHt6VFLTzrcnwSxSnwuzpD8tK6yK8bHEMXgzEm5bH3HJMD91tx+IrT4VzbcVSCjXLYGjEQwPkSNGHrANauGvcRxudw2ERQTlTrZyPUiI+nypico8xlT87IMkZR4krR0PgvHbOJWUMMPiRoDL8u49RUvXDrX6TaxCrdHgvPRcUkpPlMAx6Guo8v8dNwmzeAS+g1H3XH7SeftWri1Cb2y7/AMlTJipWuiw0rFKtEJmlKUApSlAKwazWCaAqvNPEYCoFfMtxCTlEQHEkCZOk7VSXdGa4esKFunMFJibildI1EZjr5elWDiKI+IuXCoYjEW1BLQAEUEwTpOb8hVPx2MuKxbIzAs6gDIYzMD1DUZdIk+o7msXK982amBbYUZ5VsrdZvEC5AAHKdJ6wQpZl1K5pkHz8qwmHy2rdx9GD3ASHf7gft8IMAfT1rc4Xgylg6XA15NLakAvMgyWXoAGuYwNa0+I2imHt22QqVvtCk24B0Mm4gykROuXfTtXNKTZIpVIkMBYdMHbLaZ/EcTvBWBPlt9K6TwBwMJbY7BST8ia5bg8SWw6BiTluXkHVm/6bN8WVZEydqnbvEcXZwozBGwt1SgcaPbzEg5h3B1184qXBJQySdeRFni5xX3NDFYdcdbuC4Pidyjd11JAB9J0PYzOlc64jw25hnyODE6N2Mdj5N6fmNa7FwXCZbajyFa3GuGW7qlWAMiNdvb+9u0VWx6lxfPTOrV8HMMBxi5bVgrEB4BAP8vb2ip3B8TyZXVipzecusDbTVljzqN4jy06MfD6gJOT7w9j94fj71CfpDW210Ybgj8we1WHjhk5iWFJNfMdivXrOIsqXZDn0DSAM28GfhaoO5xMlkAb7WyYW4O47T/fnVQ4LxtUuDMFYHp6hME7H6n6Va8GttgxQQAfLzAb57nWqzxyxy59iKUIrlco6hwXiYv2VuRrswHYjf+vsRSuarjbtuVttAJn57fypVz+NfoVP4Zep1+lKVqlIUpSgMV44pWKkKcrRoa96wa5atUDmOGuvh7l22yt4V9TfZpJKMpGbUzIbQamq/wAQsXHRjmlWZSQViBdllAjXUAkjtpV34/fy4e4kAs9sIg6jmgsc22xqrYjFTZddiq4YL6jwXcn/ALo+lY0rTXN8GnCXF0Wjl3h1tbdxSucCEIaCSAoaNdN2/AeVaHGMHbyO4wNxCTqxZAurAEwHJk+1TN1hh8txZbxFUtbUS5YADMg3Om49Afeq81cy4jwQHw5t5j1K2ad4gNlA1B7fyrhRfXmcwuUrXRDcIT/CKfO/e10g/Zkae23/ANVZbuKS5hcNZDAstx2dZErlzZQwGonODUJgMaLmDtAqFKXr4IGgGfxLgA9MriscAsfb3H3zFfP9kfXbtXuSW1y+1E7VpP62XfCLAkdtx/P2qJ4picsmpu4MtsH0j1/v0qi83YkhMinquMqL7uYqrCG6SiQp9slcCDcTMBI30/r2rR4iltzkuW1f3ifrt+E1ZUw62bFu2uyqB9BvVWx9yXJHYfnp/Ousfj4JFNmvg+RLd4eJZskgNEZ4E7/ebWrJgOVcSBkFtba92Zwx+izV04BgvCw9tO+WT7tqfzipKK2FpVJLe2ynLUyVpJENw7gdqymWM5Jks25O3y0A0pU1Sp/gQ9CH4kvUzSlKmIxSlKAxWGrNYY6V4wcx5xwz3FtC2RmCBdZ3KE6EahtCPmaq3ErLMxIzKgCoG1yt4du2jgeZBzCrvzGeldtUZxIkhhbLFhPczGs/jXlzCP8AC2EVFVLbICRAkm2GPSB5tqfesaqUn/1mlCVbUS63vCsXMVkzuFMCY0Q5QoJ2BIJ+dVvjXML37IVrdsi4F6eslST1KxiGEd1nWKmOFm/dwQyhE8VGK5yxIzkkbCI1n5iqNjR4Ni9YuuM73LJAn7yavHpMD5Hypskkr4sQS3P1RpcLvuto2okLdds06EFMseZPyq08EuEm2p2CD8blw/lFQnCuHZ3t2i+UkZy0Zh1hipMHapG8LmDDKxt+IBlTOwVSN1ILEA6knzqPJ81rzZO6qi6Y9oQCqLiF8TiGFtnUIzXSP4Bp+JqLwPMlzxEFzOjF4YfcdXaMwgxmEgyNIBipvl+3n4q5OyYePmzf0FeRxSxybl6P/RBNJLgs3FXMeWlVzh1jxL9tOzXEB9hqaneMyARNafJdrNi00+EXH/AKPzrnSx3Tr6iTqDZ02s0pX0JmilKUApSlAKUpQCvkia+qUBROccCEtrm69CAIjQJHrroNajOJXLjYO0cim47HpYwvSoGpG3Su/nV2xz/4mwvmHP8A2mq/zNbYNbVhGZ3IOkHMRH0BrJz49icl1ZexZL2xZH8Ox74fhtq4YuHwwQIY6yQAMokrt671V+K8Qa6puDOniPbQhlynVGzjKQQy5vzHrV4wPC4w4tqDccW2RCSFCLBUtP3ZM7axFVrD8Ja1Zv2rxyMPDNtyC9uVDTJG2YQvbYeVctykk315EkHFOT8z55YuZ0nTNadrRhQPsw4K7DdST8m9KneK8NTEWgrrJtuInurHLB8wGINVzlmLd6+isSM6up30uKG3G8ag1Z8JxBmS+jrla2WVQdSQCDmmPhMiBr8J11gQS4m2hNtHMOCAWsVdwt2WVCcgMMBBkHK3eCDpG1X3lHhN23fxF+5lPi5MjISQyASG11Ek7HaqRzCP/OXy+Qn/AER/Sun8sZv0dZ82j2n+s1LqZOk/VIjXK+xo8cbRq9+QLX2rt5WwP9TT/IVqcxNoamOQLel5vVF+iT/OuNCrmj3K6xsuVKUrdKApSlAKUpQClKUApSvh2ABJ2GtAVjmfhWLuurYZ7aEA6vBHoIykz6giq9xPB3XfCpduNOVwxU6Zw4nKTqAcs/5atv8A4mw/UJclSQyi3cYiPRQaqN3jVu5eTKcq2yVOfpJLMzCAdew03msvVbUri7vsu4VPproncDiPs2bMD4QZLgn9gkhh8u39Kq/EuY7N3Ozq7W0VCEUiSWJUG5p06mIB7GameMcGv+F9jcW2xd2MpOZXYkhtYIAO0axXN8VgWTMDdtuEYpOQKhIaIgzm37jTNXFSUFGXCJcUIyk5Lln3w3ibjFvv4arDKIiANG9CTrp5mui2cQr25BBDpIPswWPl/OuevwpbHUYfNoltQykkqhV5E5vimNtKunAMOyYcKZhMyjMCpgvbI0Pz+lQ5lG00dzXy2+ytcycPa3i3xWh8VwijuI0MgjuY2q28lYq5csMbjByHYKQoUZRECF0EfD8qheJ4i3eu3LCswuW2LHp0E7EH1Gk7g/Kp/lm3ltkDZWgt2aFA0+Y/PziuJzbjUu/28jiSW1EdzCx196s/IiRYuN+1db8Aq/yqr8fPUB+8Pzq5cnL/AIVT+0zn6uan/Dl8xFqOIE/SlK2SkKUpQClKUApSlAYrwxXwNBCnKdTsNNzXvXjiLKspVgCPI7aGfzrmXTPV2c8w+JwNu54QuILjGSWgqWLGVzEZQZkZT6VnjVq2wTNaRWQvmyALmjw2VhGxKn5Ga9Oa+SjinN+xeAZolH/VnKIEZQY08we+orVxHDjbSxaJXOwCsVLFdBbSVzahZVgCd4msuUVCPDu+y3CTlLktF27ktqbziIAJCsSdNoE/WuVYNbqhiFkK7nYGczJEq3nDH+5rrXDcSXQZhDr0uvcMN/kdwe4NcqHDL1sXXxVq4vUmUnLlaSAwzZtNIA+vaot7muWT6eotonsBFxbdxv1iIQdh0sxGwAjKykezelTibR3AT5ZriafQCoLl62FFoICBlaB31e4SNdxJ086m8DxBL1rNtcW4qMIja6BG5DfDuD37VW28t+h7kfNFbx+LR8Rcw4fIywztE6tOXNBBKrpp61a+XuGvh8Mtt2VmEklZynMSeme0HSuVXXP/ADXE+UGfoldZ4M7HDW82+XSfLtUueOyKXqk/0IrclfsV/jZ61/i/nV65TWMHZ9Un6kn+dUHjh+0Hz/Kuh8trGFsD/wBtPxUGrP4cu/sc6nwolaUpWsUhSlKAUpSgFKUoDFfNzY+xr6ryxBIViBJg6fKuZdMIojWLly3fyO6KjZiUcqdAZWB2I194qG4Xh0TElBcNwW3ADkn9mQNTsPpU3hOJpbTEK/UHLiVnp6SCGB189RIqk8LxRF+9c1JNxSND+2Y7bEED51jTpw47r9zTxxdtF15ov3Ldt7lu5DohIKwToJiO/sarHNYuOBme4y+Aj9hBPsBBk7VbOZsJ4uHfwxJe22SPMrpVZ4zjrb2LbIJD2bDg+iuM4M9tR57bVBG6v6nuJ/MkbnL2HUBMrk5LbkAtnYkXMpGbcjqMegFSr3AFLsuQ51LaRqpzEx56fU1GYYIpS4FUOq5ZJgdZ3MDTURrO/rXrxp7pBa4jsoIzNbYMMvcqxgTMTMV5JuXK7DVsqWHwj/pOLvZEJLES3VEDQQNIMSdZ2q9ctcRe9hEd068sHLGWRpplkAelQFvH4e5bP6M4yKDKFSrA9yQT3PcaVJ8kSMChWFUlyB5Sx85P41Jlk5Re5VVL9DmSSpI0OMhjcGw3Gsz9K6Py1P6JYkz9mm/tXNeMO3ib7AnQeQ9a6rgLQS0iAQFVQB7AVb/Dl2yHVPhI2qUpWoUxSlKAUpSgFKUoDFa2OtlrbhdypArZpXklao9XBQ8Byfc1Z2CMxkxGYesqJn/NFRt/Di2VeMnWyFgAASGyRO4UntsCY7iumkVy7iHA8a17MpW6AbgKZ1VAXfqQzqQwObz0HkKy9TpoxSSsu4c0pN7mkWrBuoXISAurKSdBOrJJ8iZHoY7VQ+auFC25Nu4i27hLMhZektqzJJ+FpJK7SZ0qfwV8WwHLkodCzRKkGIb/AGn1AP3qqv8AxA4Nbsm3j7dsFC0XUHwE6AMIPTI107z51WwPdLa+P3JK2PcafLeLuXcSLbk5IdWB0JiQR7zBntA8q6Pwq8yjw2PUunoR2PzHb3HaqVb5gwlpbAOdbji2SuUFANpkwV6Sde861cEksjqwgb6TmBB2PbWDPp61HmtSTqkdSlaorvMnL9q1eF+2PDL69Oiz95WH7LDX0qS5RtsmBRHUqylwQdxDGs81Xgbar3LaVsLiQLAndQA3uFEmucmRuNep4k2kyCxiZ74UbsQv1IH8662ogRXMeWrBvYtGjRCWP+XUf9xWun1q6CFQsrap/MkfVKUq+VRSlKAUpSgFKUoBSlKAwarfEcWLK3WK6qxfbUqQPrrp8qslRfF+H+IvSAWiCDsw8j5HyNV9TByj8vZ3jaUuSpPaTE2jdsZAXAlZyJcDbEadLx8JI12I00qN+zjLeExGEvYd2VlBtyU6Wn+KCskHTvPnVq4hwhTa/RwjIrMGZQjSMuq5IXKTIB8tK3bfLt97ciFgKqq7NJUebQSDqT7msuCl/RG2Xt8Uqb4OWJwa/cvRdSVS2qJG+mU5lH11PnV/wgNq2BmnvBjSewgaCs4zCvbYhwbZn7y9J9nGhrVbzNxfqKhzznOlJVRJFRrgxeuF3zHtoPT2rVx15m6FO8A+v9/lXu15dkGc+f3RUjwLgjXmk/DPW3b1Vf3j+H4Vzig5SpLk6lKMVbLDyRw0W7Ocjqfv+6NvqZP0qz152rYUBQIAAAHkBpXpX0GKGyKRlTluk2ZpSlSHIpSlAKUpQClKUApSlAKUpQGDQUpXgPG9aVgVYBgexEj8apHM3DbVvVEC/MkfQmKUqhrV8pa0vjR58r4ZLjw4kfT8qvlq2FGVQABsAIA+lKV5+H+EarxntSlK0SqKUpQClKUB/9k=',
                  fit:BoxFit.fill,
                ),

                new Text(
                  "SAXOPHONE\n",
                  style: new TextStyle(fontSize:30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Saxophone adalah alat musik tiup kayu yang terbuat dari kuningan, berbentuk seperti cangklong rokok, dan memiliki mulut tiup buluh tunggal.",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Saxophone",
                  style: new TextStyle(fontSize:25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Mouthpiece \nNeck Cork \nOctave Key \nNeck Screw \nKeys \nBell \nKey Guard \nBow \nBody \nOctave Pin \nNeck \nLigature.\n",
                  style: new TextStyle(fontSize:20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new ElevatedButton(
                  child: const Text('Flute'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const  Flute()),
                    );
                  },
                ),

              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}
class Flute extends StatelessWidget {
  const Flute({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Flute"),
      ),
      body:
      new Container(
        child:
        new SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: const EdgeInsets.all(0.0),
          child:
          new Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Image.network(
                  'https://images.tokopedia.net/img/cache/500-square/product-1/2018/8/27/8679129/8679129_8fc4bc6f-bf84-4ad6-8eb2-0d18e40f755e_1000_1000.jpg',
                  fit: BoxFit.fill,
                ),

                new Text(
                  "Flute\n",
                  style: new TextStyle(fontSize: 30.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w900,
                      fontFamily: "Roboto"),
                ),

                new Text(
                  "Flute adalah keluarga dari alat musik di woodwind kelompok. Tidak seperti alat musik tiup kayu dengan buluh , flute adalah alat musik tiup aerophone atau reedless yang menghasilkan suara dari aliran udara melintasi lubang. .",
                  style: new TextStyle(fontSize: 20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "\nBagian - Bagian Flute",
                  style: new TextStyle(fontSize: 25.0,
                      color: const Color(0xFFf40000),
                      fontWeight: FontWeight.w800,
                      fontFamily: "Roboto"),
                ),
                new Text(
                  "Foot Joint \nHead Joint \nMouthpiece \nThreaded plug or stopper \nEmbouchure \nBody or middle joint \nKey.\n ",
                  style: new TextStyle(fontSize: 20.0,
                      color: const Color(0xFF000000),
                      fontWeight: FontWeight.w300,
                      fontFamily: "Roboto"),
                ),


              ]

          ),

        ),

        padding: const EdgeInsets.all(0.0),
        alignment: Alignment.center,
      ),

    );
  }
}

